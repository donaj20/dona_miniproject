from django.urls import path,include
from . import views

urlpatterns=[
    path('googlelogin',views.googlelogin,name='googlelogin'),
    path('register',views.register,name='register'),
    path('',views.login,name='login'),
    path('logout',views.logout,name='logout'),
    path('home',views.home,name='home'),
    path('accounts/', include('allauth.urls')),
    path('cust<id>',views.cust_det,name='cust_det'),
    path('help',views.help,name='help'),
    path('sentimental',views.sentimental,name='sentimental')
]
